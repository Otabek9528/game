"""
Muslim Vegukin Bot - Generic Places API (Protected)
====================================================
Flask API with rate limiting - handles Mosques, Restaurants, and Shops

Database: 350+ places (mosques, restaurants, shops)
Expected usage: 1000 daily users
Rate limit: 200 requests/hour per IP (prevents scraping)
"""

from flask import Flask, request, jsonify
from flask_cors import CORS
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
import sqlite3
from math import radians, cos, sin, asin, sqrt
import os
from datetime import datetime

app = Flask(__name__)
CORS(app)  # Enable CORS for web app access

# ============================================
# RATE LIMITING - PROTECTS YOUR DATA
# ============================================

limiter = Limiter(
    app=app,
    key_func=get_remote_address,  # Track by IP address
    default_limits=["200 per hour"],  # 200 requests per hour per IP
    storage_uri="memory://"  # Use memory storage (simple for free tier)
)

# Custom rate limit messages
@app.errorhandler(429)
def ratelimit_handler(e):
    return jsonify({
        'success': False,
        'error': 'Rate limit exceeded. Please try again later.',
        'retry_after': str(e.description)
    }), 429

# ============================================
# CONFIGURATION
# ============================================

# Database paths
DATABASE_PATH = '/data/main_db.sqlite'
PARCELS_DATABASE_PATH = '/data/parcels.sqlite' 

# Valid building types
VALID_BUILDING_TYPES = ['Masjid', 'Oshxona', "Do'kon"]

# Logging for monitoring (helps detect scrapers)
import logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('api_usage.log'),  # Saves to file
        logging.StreamHandler()  # Also prints to console
    ]
)
logger = logging.getLogger(__name__)

# ============================================
# DATABASE FUNCTIONS
# ============================================

def get_db_connection():
    """Create database connection"""
    try:
        conn = sqlite3.connect(DATABASE_PATH)
        conn.row_factory = sqlite3.Row
        return conn
    except Exception as e:
        logger.error(f"Database connection error: {str(e)}")
        raise

def haversine(lat1, lon1, lat2, lon2):
    """
    Calculate distance between two points using Haversine formula
    Returns distance in kilometers
    """
    lon1, lat1, lon2, lat2 = map(radians, [lon1, lat1, lon2, lat2])
    
    dlon = lon2 - lon1
    dlat = lat2 - lat1
    a = sin(dlat/2)**2 + cos(lat1) * cos(lat2) * sin(dlon/2)**2
    c = 2 * asin(sqrt(a))
    
    r = 6371  # Radius of earth in kilometers
    return c * r


def get_parcels_db_connection():
    """Create parcels database connection"""
    try:
        conn = sqlite3.connect(PARCELS_DATABASE_PATH)
        conn.row_factory = sqlite3.Row
        return conn
    except Exception as e:
        logger.error(f"Parcels database connection error: {str(e)}")
        raise

# ============================================
# API ENDPOINTS
# ============================================

@app.route('/api/health', methods=['GET'])
def health_check():
    """
    Health check endpoint
    No rate limit for health checks
    """
    return jsonify({
        'status': 'ok',
        'service': 'Muslim Vegukin Bot API',
        'version': '2.0.0 (Generic)',
        'protection': 'Rate limited (200/hour per IP)',
        'supported_types': VALID_BUILDING_TYPES
    })

@app.route('/api/places/nearby', methods=['GET'])
@limiter.limit("200 per hour")
def get_nearby_places():
    """
    Get nearby places (mosques, restaurants, shops) based on user location
    
    Query Parameters:
    - lat: User's latitude (required)
    - lon: User's longitude (required)
    - building_type: Type of building (Masjid, Oshxona, Do'kon) (required)
    - limit: Number of results (default: 5, max: 10)
    
    Rate Limited: 200 requests per hour per IP
    """
    ip = get_remote_address()
    
    try:
        # Get and validate parameters
        user_lat = float(request.args.get('lat'))
        user_lon = float(request.args.get('lon'))
        building_type = request.args.get('building_type', 'Masjid')
        limit = min(int(request.args.get('limit', 5)), 10)  # Max 10 results
        
        # Validate building type
        if building_type not in VALID_BUILDING_TYPES:
            logger.warning(f"Invalid building_type '{building_type}' from IP: {ip}")
            return jsonify({
                'success': False,
                'error': f'Invalid building_type. Must be one of: {", ".join(VALID_BUILDING_TYPES)}'
            }), 400
        
        logger.info(f"GET /api/places/nearby?building_type={building_type} from IP: {ip}")
        
        # Connect to database
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Query places by building type
        cursor.execute("""
            SELECT 
                City_English,
                Name,
                Actual_address,
                Tel,
                Latitude,
                Longitude,
                KakaoMap_link,
                NaverMap_Link,
                Photo_path,
                Unique_number,
                Building_type,
                (SELECT COUNT(*) FROM reviews WHERE reviews.Unique_number = main_db.Unique_number) AS review_count,
                (SELECT AVG(Rating) FROM reviews WHERE reviews.Unique_number = main_db.Unique_number) AS avg_rating
            FROM main_db
            WHERE Building_type = ?
            ORDER BY (
                (Latitude - ?)*(Latitude - ?) + 
                (Longitude - ?)*(Longitude - ?)
            ) ASC
            LIMIT ?
        """, (building_type, user_lat, user_lat, user_lon, user_lon, limit))
        
        results = cursor.fetchall()
        conn.close()
        
        # Calculate distances and format response
        places = []
        for row in results:
            distance = haversine(user_lat, user_lon, row['Latitude'], row['Longitude'])
            
            place = {
                'id': row['Unique_number'],
                'name': row['Name'],
                'city': row['City_English'],
                'address': row['Actual_address'],
                'phone': row['Tel'],
                'distance': round(distance, 2),
                'lat': row['Latitude'],
                'lon': row['Longitude'],
                'kakaoMapUrl': row['KakaoMap_link'],
                'naverMapUrl': row['NaverMap_Link'],
                'photo': row['Photo_path'],
                'buildingType': row['Building_type'],
                'reviewCount': row['review_count'],
                'averageRating': round(row['avg_rating'], 1) if row['avg_rating'] else 0
            }
            places.append(place)
        
        logger.info(f"Returned {len(places)} {building_type}(s) to IP: {ip}")
        
        return jsonify({
            'success': True,
            'count': len(places),
            'building_type': building_type,
            'places': places
        })
        
    except ValueError as e:
        logger.warning(f"Invalid coordinates from IP: {ip} - {str(e)}")
        return jsonify({
            'success': False,
            'error': 'Invalid coordinates provided'
        }), 400
    except Exception as e:
        logger.error(f"Error in nearby_places: {str(e)}")
        return jsonify({
            'success': False,
            'error': 'Internal server error'
        }), 500

@app.route('/api/places/by-address', methods=['GET'])
@limiter.limit("200 per hour")
def get_places_by_address():
    """
    Get places near a specific address
    Uses Nominatim API first, falls back to Kakao API for better Korean address support
    
    Query Parameters:
    - address: Korean address (required)
    - building_type: Type of building (Masjid, Oshxona, Do'kon) (required)
    - limit: Number of results (default: 5, max: 10)
    
    Rate Limited: 200 requests per hour per IP
    """
    ip = get_remote_address()
    
    try:
        import requests
        
        address = request.args.get('address')
        building_type = request.args.get('building_type', 'Masjid')
        
        if not address:
            return jsonify({
                'success': False,
                'error': 'Address parameter is required'
            }), 400
        
        # Validate building type
        if building_type not in VALID_BUILDING_TYPES:
            return jsonify({
                'success': False,
                'error': f'Invalid building_type. Must be one of: {", ".join(VALID_BUILDING_TYPES)}'
            }), 400
        
        limit = min(int(request.args.get('limit', 5)), 10)
        
        logger.info(f"GET /api/places/by-address?building_type={building_type} from IP: {ip}")
        
        # Step 1: Try Nominatim API first
        lat = None
        lon = None
        geocode_source = None
        display_name = None

        try:
            geocode_url = 'https://nominatim.openstreetmap.org/search'
            params = {
                'q': address,
                'format': 'json',
                'limit': 1,
                'countrycodes': 'kr'
            }
            headers = {
                'User-Agent': 'MuslimVegukinBot/2.0'
            }
            
            response = requests.get(geocode_url, params=params, headers=headers, timeout=5)
            geocode_data = response.json()
            
            if geocode_data:
                lat = float(geocode_data[0]['lat'])
                lon = float(geocode_data[0]['lon'])
                display_name = geocode_data[0].get('display_name')
                geocode_source = 'nominatim'
                logger.info(f"Nominatim geocoded '{address}' to ({lat}, {lon})")
        except Exception as e:
            logger.warning(f"Nominatim geocoding failed for '{address}': {str(e)}")

        # Step 2: If Nominatim fails, try Kakao API
        if lat is None or lon is None:
            try:
                kakao_url = f"https://dapi.kakao.com/v2/local/search/address.json?query={address}"
                kakao_headers = {
                    "Authorization": "KakaoAK 7ed921d91204c7cf4b1adb5c6bc1e038"
                }
                
                kakao_response = requests.get(kakao_url, headers=kakao_headers, timeout=5)
                kakao_data = kakao_response.json()
                
                if kakao_data.get('documents'):
                    lat = float(kakao_data['documents'][0]['y'])
                    lon = float(kakao_data['documents'][0]['x'])
                    display_name = kakao_data['documents'][0].get('address_name', address)
                    geocode_source = 'kakao'
                    logger.info(f"Kakao geocoded '{address}' to ({lat}, {lon})")
            except Exception as e:
                logger.warning(f"Kakao geocoding failed for '{address}': {str(e)}")

        # Step 3: If both fail, return error
        if lat is None or lon is None:
            logger.warning(f"Address not found by any geocoder: {address} from IP: {ip}")
            return jsonify({
                'success': False,
                'error': 'Address not found. Please use Korean address format.'
            }), 404
        
        # Query nearby places
        conn = get_db_connection()
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT 
                City_English,
                Name,
                Actual_address,
                Tel,
                Latitude,
                Longitude,
                KakaoMap_link,
                NaverMap_Link,
                Photo_path,
                Unique_number,
                Building_type,
                (SELECT COUNT(*) FROM reviews WHERE reviews.Unique_number = main_db.Unique_number) AS review_count,
                (SELECT AVG(Rating) FROM reviews WHERE reviews.Unique_number = main_db.Unique_number) AS avg_rating
            FROM main_db
            WHERE Building_type = ?
            ORDER BY (
                (Latitude - ?)*(Latitude - ?) + 
                (Longitude - ?)*(Longitude - ?)
            ) ASC
            LIMIT ?
        """, (building_type, lat, lat, lon, lon, limit))
        
        results = cursor.fetchall()
        conn.close()
        
        places = []
        for row in results:
            distance = haversine(lat, lon, row['Latitude'], row['Longitude'])
            
            place = {
                'id': row['Unique_number'],
                'name': row['Name'],
                'city': row['City_English'],
                'address': row['Actual_address'],
                'phone': row['Tel'],
                'distance': round(distance, 2),
                'lat': row['Latitude'],
                'lon': row['Longitude'],
                'kakaoMapUrl': row['KakaoMap_link'],
                'naverMapUrl': row['NaverMap_Link'],
                'photo': row['Photo_path'],
                'buildingType': row['Building_type'],
                'reviewCount': row['review_count'],
                'averageRating': round(row['avg_rating'], 1) if row['avg_rating'] else 0
            }
            places.append(place)
        
        logger.info(f"Address search '{address}' ({geocode_source}) returned {len(places)} {building_type}(s) to IP: {ip}")
        
        return jsonify({
            'success': True,
            'count': len(places),
            'building_type': building_type,
            'geocoded_location': {
                'lat': lat,
                'lon': lon,
                'display_name': display_name,
                'source': geocode_source
            },
            'places': places
        })
        
    except Exception as e:
        logger.error(f"Error in address search: {str(e)}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500
    

@app.route('/api/place/<int:place_id>', methods=['GET'])
@limiter.limit("200 per hour")
def get_place_details(place_id):
    """
    Get detailed information about a specific place (mosque, restaurant, or shop)
    
    Parameters:
    - place_id: Unique place ID
    
    Rate Limited: 200 requests per hour per IP
    """
    ip = get_remote_address()
    logger.info(f"GET /api/place/{place_id} from IP: {ip}")
    
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Get place details (any building type)
        cursor.execute("""
            SELECT 
                City_English,
                Name,
                Actual_address,
                Tel,
                Latitude,
                Longitude,
                KakaoMap_link,
                NaverMap_Link,
                Photo_path,
                Unique_number,
                Building_type
            FROM main_db
            WHERE Unique_number = ?
        """, (place_id,))
        
        row = cursor.fetchone()
        
        if not row:
            conn.close()
            logger.warning(f"Place {place_id} not found, requested by IP: {ip}")
            return jsonify({
                'success': False,
                'error': 'Place not found'
            }), 404
        
        # Get reviews
        cursor.execute("""
            SELECT Rating, Review_Text, Timestamp, User_ID
            FROM reviews
            WHERE Unique_number = ?
            ORDER BY Timestamp DESC
        """, (place_id,))
        
        reviews_data = cursor.fetchall()
        conn.close()
        
        # Format reviews
        reviews = []
        for review in reviews_data:
            reviews.append({
                'rating': review['Rating'],
                'text': review['Review_Text'],
                'timestamp': review['Timestamp'],
                'userId': review['User_ID']
            })
        
        # Calculate average rating
        avg_rating = sum(r['rating'] for r in reviews) / len(reviews) if reviews else 0
        
        place = {
            'id': row['Unique_number'],
            'name': row['Name'],
            'city': row['City_English'],
            'address': row['Actual_address'],
            'phone': row['Tel'],
            'lat': row['Latitude'],
            'lon': row['Longitude'],
            'kakaoMapUrl': row['KakaoMap_link'],
            'naverMapUrl': row['NaverMap_Link'],
            'photo': row['Photo_path'],
            'buildingType': row['Building_type'],
            'averageRating': round(avg_rating, 1),
            'reviewCount': len(reviews),
            'reviews': reviews
        }
        
        logger.info(f"Returned details for place {place_id} ({row['Building_type']}) to IP: {ip}")
        
        return jsonify({
            'success': True,
            'place': place
        })
        
    except Exception as e:
        logger.error(f"Error getting place details: {str(e)}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/api/review/submit', methods=['POST'])
@limiter.limit("10 per hour")  # Stricter limit for review submissions
def submit_review():
    """
    Submit a review for a place
    
    JSON Body:
    - place_id: ID of the place (required)
    - user_id: Telegram user ID (required)
    - rating: Rating 1-5 (required)
    - review_text: Review text (optional)
    - timestamp: ISO timestamp (required)
    
    Rate Limited: 10 submissions per hour per IP
    """
    ip = get_remote_address()
    logger.info(f"POST /api/review/submit from IP: {ip}")
    
    try:
        data = request.get_json()
        
        # Validate required fields
        place_id = data.get('mosque_id') or data.get('place_id')  # Support both for compatibility
        user_id = data.get('user_id')
        rating = data.get('rating')
        review_text = data.get('review_text', '')
        timestamp = data.get('timestamp')
        
        if not all([place_id, user_id, rating, timestamp]):
            return jsonify({
                'success': False,
                'error': 'Missing required fields'
            }), 400
        
        # Validate rating
        if not (1 <= rating <= 5):
            return jsonify({
                'success': False,
                'error': 'Rating must be between 1 and 5'
            }), 400
        
        # Insert review into database
        conn = get_db_connection()
        cursor = conn.cursor()
        
        cursor.execute("""
            INSERT INTO reviews (Unique_number, User_ID, Rating, Review_Text, Timestamp)
            VALUES (?, ?, ?, ?, ?)
        """, (place_id, user_id, rating, review_text, timestamp))
        
        conn.commit()
        conn.close()
        
        logger.info(f"Review submitted for place {place_id} by user {user_id} (rating: {rating})")
        
        return jsonify({
            'success': True,
            'message': 'Review submitted successfully'
        })
        
    except Exception as e:
        logger.error(f"Error submitting review: {str(e)}")
        return jsonify({
            'success': False,
            'error': 'Failed to submit review'
        }), 500

@app.route('/api/stats', methods=['GET'])
def get_stats():
    """
    Get API usage statistics (for admin monitoring)
    No sensitive data exposed
    """
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Count by building type
        stats = {}
        for building_type in VALID_BUILDING_TYPES:
            cursor.execute("SELECT COUNT(*) as count FROM main_db WHERE Building_type=?", (building_type,))
            stats[building_type] = cursor.fetchone()['count']
        
        # Total reviews
        cursor.execute("SELECT COUNT(*) as count FROM reviews")
        total_reviews = cursor.fetchone()['count']
        
        conn.close()
        
        return jsonify({
            'success': True,
            'stats': {
                'places_by_type': stats,
                'total_reviews': total_reviews,
                'rate_limit': '200 requests/hour per IP',
                'max_results_per_query': 10
            }
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@app.route('/api/parcels/dates', methods=['GET'])
@limiter.limit("200 per hour")
def get_parcel_dates():
    """
    Get list of available parcel dates with post counts
    Only returns dates from today (Korea time) onwards
    """
    ip = get_remote_address()
    logger.info(f"GET /api/parcels/dates from IP: {ip}")
    
    try:
        conn = get_parcels_db_connection()
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT flight_time, flight_time_formatted, COUNT(*) as count
            FROM parcel_posts
            GROUP BY flight_time_formatted, flight_time
        """)
        rows = cursor.fetchall()
        conn.close()
        
        # Filter dates from today onwards (Korea timezone)
        from datetime import datetime
        import pytz
        korea_tz = pytz.timezone("Asia/Seoul")
        today_korea = datetime.now(korea_tz).date()
        
        dates = []
        for row in rows:
            try:
                flight_date = datetime.strptime(row['flight_time_formatted'], "%d.%m.%Y").date()
                if flight_date >= today_korea:
                    # Get weekday in Uzbek
                    uzbek_weekdays = ['Dush.', 'Sesh.', 'Chor.', 'Pay.', 'Juma', 'Shan.', 'Yak.']
                    weekday = uzbek_weekdays[flight_date.weekday()]
                    
                    dates.append({
                        'date_formatted': row['flight_time_formatted'],
                        'date_uzbek': row['flight_time'],
                        'weekday': weekday,
                        'count': row['count']
                    })
            except Exception as e:
                logger.warning(f"Invalid date format: {row['flight_time_formatted']}")
                continue
        
        # Sort by date
        dates.sort(key=lambda x: datetime.strptime(x['date_formatted'], "%d.%m.%Y"))
        
        return jsonify({
            'success': True,
            'count': len(dates),
            'dates': dates
        })
        
    except Exception as e:
        logger.error(f"Error fetching parcel dates: {str(e)}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@app.route('/api/parcels/by-date', methods=['GET'])
@limiter.limit("200 per hour")
def get_parcels_by_date():
    """
    Get parcel posts for a specific date
    Query params: date (format: DD.MM.YYYY)
    """
    ip = get_remote_address()
    date = request.args.get('date')
    
    if not date:
        return jsonify({
            'success': False,
            'error': 'Date parameter is required'
        }), 400
    
    logger.info(f"GET /api/parcels/by-date?date={date} from IP: {ip}")
    
    try:
        conn = get_parcels_db_connection()
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT telegram_id, username, message_text, flight_time, uzb_cities, kor_cities
            FROM parcel_posts
            WHERE flight_time_formatted = ?
        """, (date,))
        rows = cursor.fetchall()
        conn.close()
        
        posts = []
        for row in rows:
            posts.append({
                'telegram_id': row['telegram_id'],
                'username': row['username'],
                'message_text': row['message_text'],
                'flight_time': row['flight_time'],
                'uzb_cities': row['uzb_cities'],
                'kor_cities': row['kor_cities']
            })
        
        return jsonify({
            'success': True,
            'count': len(posts),
            'date': date,
            'posts': posts
        })
        
    except Exception as e:
        logger.error(f"Error fetching parcels by date: {str(e)}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/api/parcels/cities', methods=['GET'])
@limiter.limit("200 per hour")
def get_parcel_cities():
    """
    Get list of cities with parcel post counts
    Query params: country ('uzb' or 'kor')
    """
    ip = get_remote_address()
    country = request.args.get('country', 'uzb')
    
    if country not in ['uzb', 'kor']:
        return jsonify({
            'success': False,
            'error': 'Country must be "uzb" or "kor"'
        }), 400
    
    logger.info(f"GET /api/parcels/cities?country={country} from IP: {ip}")
    
    column = 'uzb_cities' if country == 'uzb' else 'kor_cities'
    
    try:
        conn = get_parcels_db_connection()
        cursor = conn.cursor()
        
        cursor.execute(f"""
            SELECT {column}, flight_time_formatted
            FROM parcel_posts
            WHERE {column} IS NOT NULL
        """)
        rows = cursor.fetchall()
        conn.close()
        
        # Filter by date (today onwards in Korea timezone)
        from datetime import datetime
        from collections import Counter
        import pytz
        
        korea_tz = pytz.timezone("Asia/Seoul")
        today_korea = datetime.now(korea_tz).date()
        
        counter = Counter()
        
        for row in rows:
            try:
                flight_date = datetime.strptime(row['flight_time_formatted'], "%d.%m.%Y").date()
                if flight_date < today_korea:
                    continue
            except:
                continue
            
            city_field = row[column]
            if city_field:
                cities = city_field.split(",")
                cleaned = [c.strip().capitalize() for c in cities if c.strip()]
                counter.update(cleaned)
        
        # Sort alphabetically
        cities = [{'city': city, 'count': count} for city, count in sorted(counter.items())]
        
        return jsonify({
            'success': True,
            'country': country,
            'count': len(cities),
            'cities': cities
        })
        
    except Exception as e:
        logger.error(f"Error fetching parcel cities: {str(e)}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@app.route('/api/parcels/by-city', methods=['GET'])
@limiter.limit("200 per hour")
def get_parcels_by_city():
    """
    Get parcel posts for a specific city
    Query params: city, country ('uzb' or 'kor')
    """
    ip = get_remote_address()
    city = request.args.get('city')
    country = request.args.get('country', 'uzb')
    
    if not city:
        return jsonify({
            'success': False,
            'error': 'City parameter is required'
        }), 400
    
    if country not in ['uzb', 'kor']:
        return jsonify({
            'success': False,
            'error': 'Country must be "uzb" or "kor"'
        }), 400
    
    logger.info(f"GET /api/parcels/by-city?city={city}&country={country} from IP: {ip}")
    
    column = 'uzb_cities' if country == 'uzb' else 'kor_cities'
    
    try:
        conn = get_parcels_db_connection()
        cursor = conn.cursor()
        
        cursor.execute(f"""
            SELECT telegram_id, username, message_text, flight_time, flight_time_formatted, uzb_cities, kor_cities
            FROM parcel_posts
            WHERE {column} LIKE ?
        """, (f"%{city}%",))
        rows = cursor.fetchall()
        conn.close()
        
        # Filter by date (today onwards in Korea timezone)
        from datetime import datetime
        import pytz
        
        korea_tz = pytz.timezone("Asia/Seoul")
        today_korea = datetime.now(korea_tz).date()
        
        posts = []
        for row in rows:
            try:
                flight_date = datetime.strptime(row['flight_time_formatted'], "%d.%m.%Y").date()
                if flight_date < today_korea:
                    continue
            except:
                continue
            
            posts.append({
                'telegram_id': row['telegram_id'],
                'username': row['username'],
                'message_text': row['message_text'],
                'flight_time': row['flight_time'],
                'date_formatted': row['flight_time_formatted'],
                'uzb_cities': row['uzb_cities'],
                'kor_cities': row['kor_cities']
            })
        
        return jsonify({
            'success': True,
            'city': city,
            'country': country,
            'count': len(posts),
            'posts': posts
        })
        
    except Exception as e:
        logger.error(f"Error fetching parcels by city: {str(e)}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


# ============================================
# RUN APPLICATION
# ============================================

if __name__ == '__main__':
    # Check database exists
    if not os.path.exists(DATABASE_PATH):
        print(f"⚠️  WARNING: Database not found at {DATABASE_PATH}")
        print("Please update DATABASE_PATH in the script")
    else:
        print(f"✅ Database found at {DATABASE_PATH}")
    
    print("\n" + "="*60)
    print("🕌 Muslim Vegukin Bot API - Generic Places (Protected)")
    print("="*60)
    print("\n📊 Configuration:")
    print(f"  • Rate Limit: 200 requests/hour per IP")
    print(f"  • Max Results: 10 places per query")
    print(f"  • Database: {DATABASE_PATH}")
    print(f"  • Logging: api_usage.log")
    print(f"  • Supported Types: {', '.join(VALID_BUILDING_TYPES)}")
    print("\n🔒 Data Protection:")
    print(f"  • Database file NOT exposed to users")
    print(f"  • Only query results returned")
    print(f"  • Rate limiting prevents mass scraping")
    print(f"  • All requests logged for monitoring")
    print("\n📍 Endpoints:")
    print("  • GET /api/health")
    print("  • GET /api/places/nearby?lat=X&lon=Y&building_type=Masjid&limit=5")
    print("  • GET /api/places/by-address?address=서울시&building_type=Oshxona&limit=5")
    print("  • GET /api/place/<id>")
    print("  • POST /api/review/submit")
    print("  • GET /api/stats")
    print("\n🚀 Starting server...")
    print("="*60 + "\n")
    
    # Run the app
    app.run(debug=True, host='0.0.0.0', port=5000)